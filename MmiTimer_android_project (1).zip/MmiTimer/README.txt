[APK 만드는 법]
1. 안드로이드 스튜디오(Android Studio) 설치 후 이 폴더(MmiTimer)를 Open
2. 하단에 Gradle Sync가 끝날 때까지 대기 (처음엔 몇 분 걸림, 인터넷 필요)
3. 메뉴 Build > Build Bundle(s) / APK(s) > Build APK(s)
4. 완료 알림의 locate 클릭 -> app/build/outputs/apk/debug/app-debug.apk
5. 이 파일을 폰으로 옮겨 설치 (설정에서 '출처를 알 수 없는 앱 설치' 허용)

[처음 실행]
- '10분 시작'을 누르면 '다른 앱 위에 표시' 설정 화면이 열림 -> MMI 타이머 허용
- 뒤로 돌아와 다시 '10분 시작' 누르면 시작 (알림 권한도 허용 권장)
- 알림: 경과 1:30, 8:30, 9:30 / 종료 10:00 (진동+소리, 화면 전체를 빨간 타이머가 6초간 덮음 / 터치하면 닫힘)
- 타이머 드래그=이동, 1.5초 길게 누르기=종료
- 알림 시점 변경: TimerService.kt 의 MARKS = intArrayOf(90, 510, 570) (초 단위)

[PC 없이 폰으로 APK 만들기 - GitHub Actions]
1. github.com 가입 -> 새 저장소(Repository) 생성
2. 이 폴더의 파일을 저장소에 업로드 (.github 폴더 포함, 폰은 '데스크톱 사이트'로 보면 편함)
3. Actions 탭 -> Build APK 실행 (push하면 자동 실행)
4. 완료 후 Artifacts의 app-debug 다운로드 -> zip 풀면 app-debug.apk -> 설치
