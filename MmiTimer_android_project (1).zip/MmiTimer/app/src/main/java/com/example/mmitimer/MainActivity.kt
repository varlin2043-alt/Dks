package com.example.mmitimer

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        val title = TextView(this).apply {
            text = "MMI 면접 타이머 (10분)"
            textSize = 24f
        }
        val info = TextView(this).apply {
            text = "알림: 경과 1:30 · 8:30 · 9:30 (진동 + 소리)\n" +
                "시작하면 다른 앱 위에 타이머가 떠요.\n" +
                "알림 시점이 되면 화면 전체가 빨갛게 덮여요(6초, 터치하면 닫힘).\n" +
                "타이머를 드래그하면 위치 이동,\n" +
                "1.5초 길게 누르면 종료됩니다."
            textSize = 16f
            setPadding(0, pad / 2, 0, pad)
        }
        val start = Button(this).apply {
            text = "10분 시작"
            textSize = 22f
            setOnClickListener { startTimer() }
        }
        val stop = Button(this).apply {
            text = "종료"
            textSize = 18f
            setOnClickListener { stopService(Intent(this@MainActivity, TimerService::class.java)) }
        }
        root.addView(title)
        root.addView(info)
        root.addView(start)
        root.addView(stop)
        setContentView(root)
    }

    private fun startTimer() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "'다른 앱 위에 표시'를 허용한 뒤 돌아와서 다시 눌러주세요", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, TimerService::class.java))
        moveTaskToBack(true)
    }
}
