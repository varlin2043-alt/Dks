package com.example.mmitimer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.ceil

class TimerService : Service() {

    companion object {
        const val TOTAL = 600                      // 10분(초)
        val MARKS = intArrayOf(90, 510, 570)       // 경과 1:30, 8:30, 9:30
        const val NORMAL_BG = 0xE6111827.toInt()
        const val ALERT_BG = 0xF0DC2626.toInt()
        const val FULL_MS = 6000L                  // 전체화면 유지 시간
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var view: TextView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var fullScreen = false
    private var label = ""
    private val bg = GradientDrawable()
    private var startMs = 0L
    private val fired = BooleanArray(MARKS.size)
    private var lastAlertMs = 0L
    private var tone: ToneGenerator? = null
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (view != null) return START_NOT_STICKY // 이미 실행 중

        val channelId = "timer"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "면접 타이머", NotificationManager.IMPORTANCE_LOW)
        )
        val notification: Notification = Notification.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("MMI 타이머 실행 중")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notification)
        }

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mmitimer:wake").apply {
            acquire(11 * 60 * 1000L)
        }
        tone = try { ToneGenerator(AudioManager.STREAM_ALARM, 100) } catch (e: Exception) { null }

        showOverlay()
        startMs = SystemClock.elapsedRealtime()
        handler.post(tick)
        return START_NOT_STICKY
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showOverlay() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        bg.setColor(NORMAL_BG)
        bg.cornerRadius = dp(16).toFloat()

        val tv = TextView(this).apply {
            text = "10:00"
            textSize = 34f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(18), dp(10), dp(18), dp(10))
            background = bg
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(120)
        }

        this.lp = lp
        var downX = 0f
        var downY = 0f
        var origX = 0
        var origY = 0
        var moved = false
        val longPress = Runnable { stopSelf() }

        tv.setOnTouchListener { _, e ->
            if (fullScreen) {
                if (e.action == MotionEvent.ACTION_UP) exitFull()
                return@setOnTouchListener true
            }
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    origX = lp.x; origY = lp.y
                    downX = e.rawX; downY = e.rawY
                    moved = false
                    handler.postDelayed(longPress, 1500)
                }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (e.rawX - downX).toInt()
                    val my = (e.rawY - downY).toInt()
                    if (abs(mx) > 15 || abs(my) > 15) {
                        moved = true
                        handler.removeCallbacks(longPress)
                    }
                    if (moved) {
                        lp.x = origX + mx
                        lp.y = origY + my
                        wm.updateViewLayout(tv, lp)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(longPress)
            }
            true
        }
        wm.addView(tv, lp)
        view = tv
    }

    private val tick = object : Runnable {
        override fun run() {
            val e = (SystemClock.elapsedRealtime() - startMs) / 1000.0
            for (i in MARKS.indices) {
                if (!fired[i] && e >= MARKS[i]) {
                    fired[i] = true
                    alert(false)
                }
            }
            val left = ceil(TOTAL - e).toInt().coerceAtLeast(0)
            val t = "%d:%02d".format(left / 60, left % 60)
            view?.text = if (fullScreen) "$label\n$t\n(화면을 터치하면 닫혀요)" else t
            val now = SystemClock.elapsedRealtime()
            if (lastAlertMs > 0 && now - lastAlertMs >= 10000 && e < TOTAL) bg.setColor(NORMAL_BG)

            if (e >= TOTAL) {
                alert(true)
                handler.postDelayed({ stopSelf() }, FULL_MS)
                return
            }
            handler.postDelayed(this, 200)
        }
    }

    private fun enterFull(text: String) {
        val v = view ?: return
        val l = lp ?: return
        label = text
        fullScreen = true
        l.width = WindowManager.LayoutParams.MATCH_PARENT
        l.height = WindowManager.LayoutParams.MATCH_PARENT
        l.x = 0; l.y = 0
        l.flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
        v.gravity = Gravity.CENTER
        v.textSize = 64f
        v.setPadding(dp(24), dp(24), dp(24), dp(24))
        bg.cornerRadius = 0f
        wm.updateViewLayout(v, l)
        handler.removeCallbacks(exitFullRunnable)
        handler.postDelayed(exitFullRunnable, FULL_MS)
    }

    private val exitFullRunnable = Runnable { exitFull() }

    private fun exitFull() {
        if (!fullScreen) return
        val v = view ?: return
        val l = lp ?: return
        handler.removeCallbacks(exitFullRunnable)
        fullScreen = false
        l.width = WindowManager.LayoutParams.WRAP_CONTENT
        l.height = WindowManager.LayoutParams.WRAP_CONTENT
        l.x = dp(16); l.y = dp(120)
        l.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        v.gravity = Gravity.START
        v.textSize = 34f
        v.setPadding(dp(18), dp(10), dp(18), dp(10))
        bg.cornerRadius = dp(16).toFloat()
        wm.updateViewLayout(v, l)
    }

    private fun alert(isEnd: Boolean) {
        lastAlertMs = SystemClock.elapsedRealtime()
        bg.setColor(ALERT_BG)
        val e = ((SystemClock.elapsedRealtime() - startMs) / 1000.0).toInt()
        val shown = if (isEnd) TOTAL else MARKS.minByOrNull { abs(it - e) } ?: e
        enterFull(if (isEnd) "10분 종료" else "경과 %d분 %02d초".format(shown / 60, shown % 60))
        val pattern = if (isEnd) longArrayOf(0, 800, 200, 800) else longArrayOf(0, 400, 150, 400, 150, 400)
        vibrator().vibrate(VibrationEffect.createWaveform(pattern, -1))
        tone?.startTone(ToneGenerator.TONE_PROP_BEEP2, if (isEnd) 1000 else 600)
    }

    @Suppress("DEPRECATION")
    private fun vibrator(): Vibrator =
        if (Build.VERSION.SDK_INT >= 31)
            getSystemService(VibratorManager::class.java).defaultVibrator
        else
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { view?.let { wm.removeView(it) } } catch (e: Exception) { }
        view = null
        tone?.release()
        try { wake?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
        super.onDestroy()
    }
}
